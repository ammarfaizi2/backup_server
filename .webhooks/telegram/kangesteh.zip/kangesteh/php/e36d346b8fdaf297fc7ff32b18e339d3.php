<?php ini_set("display_errors",true);ini_set("max_execution_time",10);ini_set("memory_limit","50M");unset($_SERVER);set_time_limit(30);
$input = "aA1aa"; $f=true;
$pattern = array("a-z","A-Z","0-9");
foreach($pattern as $q){
if(!preg_match("#[".$q."]#",$input)){
$f=false;break;}}

if(!$f){ print "pola password salah";}else{print "password diterima";}