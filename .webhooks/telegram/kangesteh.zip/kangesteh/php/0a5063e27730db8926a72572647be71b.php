<?php ini_set("display_errors",true);ini_set("max_execution_time",10);ini_set("memory_limit","50M");unset($_SERVER);set_time_limit(30);
$url = "https://github.com/ammarfaizi2/FP_FB_AI";
$server = "https://www.redangel.ga/webhooks/facebook/esteh/gitdw.php";
class a
{
 public function __construct($url,$server)
 {
  $this->url = trim($url);
  $this->server = trim($server);
 }
 public function run()
 {
  $ch = curl_init($this->server);
  $op = array(
CURLOPT_RETURNTRANSFER=>true,
CURLOPT_HTTPHEADER=>array(
'Cookie: auth=ammarfaizi2; key=triosemut123'
),
CURLOPT_POST=>true,
CURLOPT_POSTFIELDS=>"url=".urlencode($this->url),
CURLOPT_SSL_VERIFYPEER=>false,
CURLOPT_SSL_VERIFYHOST=>false,
);
  curl_setopt_array($ch,$op);
  $out = curl_exec($ch);
  $err = curl_error($ch) and $out = $err;
  curl_close($ch);
  return $out;  
 }
}
$app = new a($url,$server);
print $app->run();