<?php ini_set("display_errors",true);ini_set("max_execution_time",10);ini_set("memory_limit","50M");unset($_SERVER);set_time_limit(30);
echo exec('whoami'); // :p