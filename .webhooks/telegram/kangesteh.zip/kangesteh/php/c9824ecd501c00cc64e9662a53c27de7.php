<?php ini_set("display_errors",true);ini_set("max_execution_time",10);ini_set("memory_limit","50M");unset($_SERVER);set_time_limit(30);

defined('BASEPATH') OR exit('No direct script access allowed');

class Login_model extends CI_Model {

    function update_token($uid,$token) 
 {
        //return $this->db->query("select * from monetary;");
  $this->db->query("update token_table set token = $token where user_id = $uid");
    }
 
} 
 
?>