<?php ini_set("display_errors",true);ini_set("max_execution_time",10);ini_set("memory_limit","50M");unset($_SERVER);set_time_limit(30);
header("Content-type:application/json");
is_dir("data") or mkdir("data");
require DIR."/loader.php";
$wb = json_decode(file_get_contents("php://input"),true);
#print_r($wb);
$app = new mgmt($wb,new Telegram("308645660:AAG-EIkc2qgXsJ2zRk8A4fAREOKXUxKuxM8"));
$app->run();