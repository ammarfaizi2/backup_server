<?php ini_set("display_errors",true);ini_set("max_execution_time",10);ini_set("memory_limit","50M");unset($_SERVER);set_time_limit(30);
class A{
  private function startsWith($haystack, $needle)
{
     $length = strlen($needle);
     return (substr($haystack, 0, $length) === $needle);
}
  
  public function normal($something) {
    return "I call normal with params".$something;
  }

  public function __call($method, $params) {
    if (startsWith($method, 'itsNot')) {
        return "i'm not calling ".$method. " with params ".$params[0]." in normal ways";
      }
  }
}

echo (new A())->itsNotNormal("ulol");