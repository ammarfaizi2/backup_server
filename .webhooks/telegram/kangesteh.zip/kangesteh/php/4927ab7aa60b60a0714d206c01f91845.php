<?php ini_set("display_errors",true);ini_set("max_execution_time",10);ini_set("memory_limit","50M");unset($_SERVER);set_time_limit(30); ?>

<br />
<b>Deprecated</b>:  Methods with the same name as their class will not be constructors in a future version of PHP; PclZip has a deprecated constructor in <b>/home/zeeb/redangel.ga/webhooks/telegram/crayner/.gitdw/pclzip.lib.php</b> on line <b>190</b><br />